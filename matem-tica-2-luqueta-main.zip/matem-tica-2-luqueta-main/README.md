# matem-tica-2-luqueta
Repositório de matemática do luqueta 
